import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Expense, budget } from '../../model/expesne';






@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class HomeComponent implements OnInit {
  model: Expense;
  list: any;
  List: any = [];
  piechart: [];
  bud: number;
  ExpenseData: any = [];
  totalspent:number;
catsplet:any=[];
  qw:any=[];

  constructor() {
    this.model = new Expense();
  }



  addForm() {
var data = this.model.amount + this.totalspent;
console.log(data);
if(data> this.bud){
  alert('Your Expense is greater than your Budget');
}
else{
  this.List.push(this.model);
  localStorage.setItem('expense', JSON.stringify(this.List));

  this.getAll();
}



  }

  getAll() {
this.totalspent=0;
this.catsplet=[];
    if (localStorage.getItem('expense') === null) {
      this.List = [];
    }
    else {
      this.List = JSON.parse(localStorage.getItem('expense'));
      this.List.forEach(element => {
        this.totalspent+=parseInt (element.amount);
  if(this.catsplet.length>0){
    this.catsplet.forEach(celement => {
      if(celement.name == element.category){
        celement.amount = parseInt(celement.amount)+parseInt(element.amount);
      }
      else{
        var obj = {name:element.category,amount:element.amount};
        this.catsplet.push(obj);
      }
      
    });
  }
  else{
    var obj = {name:element.category,amount:element.amount};
    this.catsplet.push(obj);
  }
      
      });
     
    }

  }


  // expenseDetails(id) {
  //   alert(id);
  //   this.sevs.getExpenseByid(id).subscribe((data) => {
  //     this.List = data;


  //   })
  // }

  editExpDetails(li) {

    this.model = li;
  }

  updateDetails() {

    for (let index = 0; index < this.List.length; index++) {
      if (this.List[index].Id == this.model.Id) {

        this.List[index] = this.model;


        localStorage.setItem('expense', JSON.stringify(this.List));
        this.getAll();
      }

    }


  }

  getcat(){
    this.qw = JSON.parse(localStorage.getItem('category'));
  }

  expenseDelete(id) {

    for (let index = 0; index < this.List.length; index++) {
      if (this.List[index].Id == id) {

        var data = this.List;
        data.splice(index, 1);
        this.List = data;

        localStorage.setItem('expense', JSON.stringify(this.List));
      }

    }
    this.getAll();
  }

  clearDetails() {
this.model= new Expense();
  }

getBudget(){
       this.bud= JSON.parse(localStorage.getItem('Budget'))
}
  ngOnInit() {
    this.getAll();

this.getBudget();

  }


}


