import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import {SettingsComponent} from './settings/settings.component';
import {ProfileComponent} from './profile/profile.component'

const routes: Routes = [{path:'Home',component:HomeComponent},
{path:'Settings',component:SettingsComponent},
{path:'Profile',component:ProfileComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExpensemanagementRoutingModule { }
