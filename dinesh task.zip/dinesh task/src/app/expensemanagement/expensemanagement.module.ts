import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';
import { ExpensemanagementRoutingModule } from './expensemanagement-routing.module';
import { HomeComponent } from './home/home.component';
import { SettingsComponent } from './settings/settings.component';
import { ProfileComponent } from './profile/profile.component';



@NgModule({
  declarations: [HomeComponent, SettingsComponent, ProfileComponent],
  imports: [
    CommonModule,
    ExpensemanagementRoutingModule,FormsModule
  ]
})
export class ExpensemanagementModule { }
