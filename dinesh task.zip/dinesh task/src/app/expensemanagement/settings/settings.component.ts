// 


import { Component, OnInit } from '@angular/core';
import { budget } from 'src/app/model/expesne';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
  localobj: any= [];
  getdata: any[]= [];
  bud: any;
   budgetmodel = budget;


   qw:any[]=[];

  constructor() {
    this.qw=[];
   }
  

  total(data:any){

    if(data){
      localStorage.setItem('Budget', JSON.stringify(data));
      this.gettotal();
    }
    
   
  }


  addcat(data){

    if(data){
      this.qw.push(data)

      localStorage.setItem('category',JSON.stringify(this.qw));
      this.getcat();
    }

  }


getcat(){
  this.qw = JSON.parse(localStorage.getItem('category'));
}
gettotal(){
  this.bud = JSON.parse(localStorage.getItem('category'));
}
deletecat(data){
  alert(data)
  for (let index = 0; index < this.qw.length; index++) {
    if(this.qw[index]==data){
      var data1 = this.qw
      data1.splice(index,1);
      this.qw = data1;
      localStorage.setItem('category',JSON.stringify( this.qw));
      this.getcat();
    }
    
  }
}
  ngOnInit() {      
    
    localStorage.setItem('category',JSON.stringify(this.qw));
this.getcat();
this.gettotal();

    
  }

}
