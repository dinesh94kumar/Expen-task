import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './expensemanagement/home/home.component'

const routes: Routes = [
  {path:'Expense',loadChildren:"../app/expensemanagement/expensemanagement.module#ExpensemanagementModule"},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
