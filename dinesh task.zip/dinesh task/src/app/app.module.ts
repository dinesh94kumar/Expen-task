import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ChartModule } from '@syncfusion/ej2-angular-charts'
import { AccumulationChartModule, PieSeriesService, AccumulationLegendService,
  AccumulationDataLabelService, AccumulationTooltipService} from '@syncfusion/ej2-angular-charts'
// import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    AppComponent,



  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, RouterModule, HttpClientModule,ChartModule ,AccumulationChartModule,
    
  ],
  providers: [PieSeriesService, AccumulationDataLabelService,AccumulationLegendService, AccumulationTooltipService],
  bootstrap: [AppComponent]
})
export class AppModule { }
