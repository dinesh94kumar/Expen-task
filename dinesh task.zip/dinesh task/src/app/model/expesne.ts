export class Expense{
Id:number;
category:string;
itemName:any;
amount:number;
expenseDate:Date;
}

export class budget{
    totalamount : number;
    category:string;
    
}