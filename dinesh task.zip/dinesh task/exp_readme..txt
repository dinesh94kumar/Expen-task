Expense Management System

=> Frist Download the zip file,
=> Open  the code in Visual Studio Code


Installing:

=> Install node moduls "npm install"
=> Install node moduls "npm install Bootstrap --save"


Running the Build:

=> To run the code "ng s"(fig:01)


Steps to process the Application:

=> First go to Settings to add the Budget & Categories to do so click on "Settings" (fig:02)
    -> add budget amount in input field  of Total amount and click on "update" &
    -> add Categories name in input field  of categories and click on "Add"
         > If u want to delete the categories then click on Delete icon and conformation.(fig:03)


=>Go to Home to add expense and to see the budget value to do so click on "Home"(fig:05)
	->First click on add Expense and fill the data with different id and rest of the input fields (fig:06)
        ->The user can see the added item in the table and also he can delete and edits the data
	->To Delete the data click on delete icon
	->To Edit the data click on edit icon and rewrite the data then click update


=>user can see the total Budget in Budget Overview box and also he can see the expened amount 
=>user can see the total Category Wise  in Category Wise Split box and also he can see the expened amount Category 
=> if user going to add more the budget amount it will show a alert.(fig:08)



               

 







